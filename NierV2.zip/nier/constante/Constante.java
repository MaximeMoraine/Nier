package nier.constante;


/**
 * Décrivez votre classe Constante ici.
 *
 * @author (votre nom)
 * @version (un numéro de version ou une date)
 */
public abstract class Constante {
   public static final int FPS = 30;
   public static final int SECONDE = 1000;
   // Taille de la bordure de la fenetre. Code a améliorer (sale).
   public static final int BORDER_SIZE = 20;
   public static final int ADD_SIZE = 22;
    
   public static final int MAX_DEGREE = 360;
   public static final int DEGRE_45 = 45;
   public static final int DEGRE_90 = 90;
   
   public static final int CIRCLE = 0;
   public static final int GENERATOR = 1;
   public static final int ENEMY = 2;
   public static final int PLAYER = 3;
   public static final int PROJECT_PLAYER = 4;
}
