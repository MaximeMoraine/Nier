package nier.exception;

/**
 * Exeption en cas de coordonnée incorrecte du à une sortie de champs.
 */
public class OutOfAreaException extends Exception {
    
}
