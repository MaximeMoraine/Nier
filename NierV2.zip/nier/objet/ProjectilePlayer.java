package nier.objet;

import nier.constante.Constante;
import nier.deplacement.ICoord;
import nier.deplacement.PolarCoord;
import nier.deplacement.IMovement;

import java.util.Iterator;

/**
 * Projectile du joueurs.
 */
public class ProjectilePlayer extends Projectile {
    
    // Attribut
    
        private boolean hasAttacked;
        
        
    // Constantes
    
        public static final int FORM = Constante.PROJECT_PLAYER;
        public static final int WIDTH = 8;
        public static final int HEIGHT = 14;
        
        
    // Constructeur
    
    public ProjectilePlayer(PolarCoord pos, IMovement mov, Actor creat) {
        super(pos, mov, 1, 1, creat);
        hasAttacked = false;
    }
    
    
    // Requête

    public int getForm() {
        return FORM;
    }
    
    public int getWidth() {
        return WIDTH;
    }
    
    public int getHeight() {
        return HEIGHT;
    }
    
    public boolean canBeDestroyed() {
        if (!isAlive()) {
            throw new AssertionError();
        }
        
        return false;
    }
    
    
    // Methode
    
    /**
     * étend push de projectile en rajoutant le traitement des colisions
     * associé aux projectiles du joueur.
     */
    public void push() {
        super.push();
        
        //Gestion des colisions.
        
        if (getLife() > 0) {
            
            // Ordre établi ainsi car le projectile du joueur est un rectangle
            // ce qui facilite ses calculs.
            // Carré de colision avec le projectile du joueur
            // qui est un rectangle.
            int pX = getPosition().getCol();
            int pX2 = getPosition().getCol() + getWidth();
            int pY = getPosition().getRow();
            int pY2 = getPosition().getRow() - getHeight();
            
            // Colision sur les Projectile rouge.
            Iterator i = ProjectileRed.getAllProjectileRed().iterator();
            
            while (i.hasNext() && !hasAttacked) {
                ProjectileRed p = (ProjectileRed) i.next();
                ICoord c = p.getPosition();
                
                int moitXp = p.getWidth() / 2;
                int moitYp = p.getHeight() / 2;
                int per10Xp = p.getWidth() / 10;
                int per10Yp = p.getHeight() / 10;
                
                // Point cardinaux recevant les collisions sur le projectile
                // rouge
                int point1X = c.getCol();
                int point2X = c.getCol() + per10Xp;
                int point3X = c.getCol() + moitXp;
                int point4X = c.getCol() + p.getWidth() - per10Xp;
                int point5X = c.getCol() + p.getWidth();
                int point1Y = c.getRow();
                int point2Y = c.getRow() - per10Yp;
                int point3Y = c.getRow() - moitYp;
                int point4Y = c.getRow() - p.getHeight() + per10Yp;
                int point5Y = c.getRow() - p.getHeight();

                // Si le projectile rouge est dans la hit box
                // du projectile du joueur:
                // 8 points cardinaux
                if (pX <= point2X && point2X <= pX2
                    &&  pY >= point2Y && point2Y >= pY2
                 || pX <= point3X && point3X <= pX2
                    && pY >= point1Y && point1Y >= pY2
                 || pX <= point4X && point4X <= pX2
                    && pY >= point2Y && point2Y >= pY2
                 || pX <= point5X && point5X <= pX2
                    && pY >= point3Y && point3Y >= pY2
                 || pX <= point4X && point4X <= pX2
                    && pY >= point4Y && point4Y >= pY2
                 || pX <= point3X && point3X <= pX2
                    && pY >= point5Y && point5Y >= pY2
                 || pX <= point2X && point2X <= pX2
                    && pY >= point4Y && point4Y >= pY2
                 || pX <= point1X && point1X <= pX2
                    && pY >= point3Y && point3Y >= pY2
                 || pX <= point3X && point3X <= pX2
                    && pY >= point3Y && point3Y >= pY2) {
                               
                    this.setLife(0);
                    p.setLife(p.getLife() - this.getDammage());
                    hasAttacked = true;
                }
            }
            
            
            // Colision sur les generateurs.
            i = Generator.getAllGenerator().iterator();
            
            while (i.hasNext() && !hasAttacked) {
                Generator g = (Generator) i.next();
                ICoord c = g.getPosition();
                
                int moitXp = g.getWidth() / 2;
                int moitYp = g.getHeight() / 2;
                int per8Xp = g.getWidth() / 8;
                int per8Yp = g.getHeight() / 8;
                int per4Xp = g.getWidth() / 4;
                int per4Yp = g.getHeight() / 4;
                int per30Xp = g.getWidth() / 30; // Le 30 n'a aucune.
                int per30Yp = g.getHeight() / 30; // signification. Arbitraire.
                
                // Point cardinaux recevant les collisions sur le générateur.
                int point1X = c.getCol();
                int point2X = c.getCol() + per8Xp;
                int point3X = c.getCol() + moitXp;
                int point4X = c.getCol() + g.getWidth() - per8Xp;
                int point5X = c.getCol() + g.getWidth();
                int point1Y = c.getRow();
                int point2Y = c.getRow() - per8Yp;
                int point3Y = c.getRow() - moitYp;
                int point4Y = c.getRow() - g.getHeight() + per8Yp;
                int point5Y = c.getRow() - g.getHeight();
                
                // point rajouté pour une meilleure hitBox.
                int point6X = c.getCol() + per30Xp;
                int point7X = c.getCol() + per4Xp;
                int point8X = c.getCol() + g.getWidth() - per4Xp;
                int point9X = c.getCol() + g.getWidth() - per30Xp;
                int point6Y = c.getRow() - per30Xp;
                int point7Y = c.getRow() - per4Xp;
                int point8Y = c.getRow() - g.getHeight() + per4Xp;
                int point9Y = c.getRow() - g.getHeight() + per30Xp;
                
                // Si le generateur est dans la hit box du projectile.
                // 9 points cardinaux
                if (pX <= point2X && point2X <= pX2
                    &&  pY >= point2Y && point2Y >= pY2
                 || pX <= point3X && point3X <= pX2
                    && pY >= point1Y && point1Y >= pY2
                 || pX <= point4X && point4X <= pX2
                    && pY >= point2Y && point2Y >= pY2
                 || pX <= point5X && point5X <= pX2
                    && pY >= point3Y && point3Y >= pY2
                 || pX <= point4X && point4X <= pX2
                    && pY >= point4Y && point4Y >= pY2
                 || pX <= point3X && point3X <= pX2
                    && pY >= point5Y && point5Y >= pY2
                 || pX <= point2X && point2X <= pX2
                    && pY >= point4Y && point4Y >= pY2
                 || pX <= point1X && point1X <= pX2
                    && pY >= point3Y && point3Y >= pY2
                 || pX <= point3X && point3X <= pX2
                    && pY >= point3Y && point3Y >= pY2
                    
                 // Rajout
                 || pX <= point7X && point7X <= pX2
                    && pY >= point6Y && point6Y >= pY2
                 || pX <= point8X && point8X <= pX2
                    && pY >= point6Y && point6Y >= pY2
                 || pX <= point9X && point9X <= pX2
                    && pY >= point7Y && point7Y >= pY2
                 || pX <= point9X && point9X <= pX2
                    && pY >= point8Y && point8Y >= pY2
                 || pX <= point8X && point8X <= pX2
                    && pY >= point9Y && point9Y >= pY2
                 || pX <= point7X && point7X <= pX2
                    && pY >= point9Y && point9Y >= pY2 
                 || pX <= point6X && point6X <= pX2
                    && pY >= point8Y && point8Y >= pY2
                 || pX <= point6X && point6X <= pX2
                    && pY >= point7Y && point7Y >= pY2) {
                    
                    this.setLife(0);
                    g.setLife(g.getLife() - this.getDammage());
                    hasAttacked = true;
                }
            }
                
        }
    }       
}
